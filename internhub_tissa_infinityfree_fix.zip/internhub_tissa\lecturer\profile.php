<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/management_helpers.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'lecturer') {
    header("Location: ../login.php");
    exit();
}

$lecturer_id = $_SESSION['lecturer_id'];
ensure_management_schema($pdo);
$message = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_profile'])) {
    try {
        $stmt = $pdo->prepare("
            UPDATE lecturer
            SET lecturer_staff_id = ?, lecturer_programme = ?, lecturer_name = ?,
                lecturer_gender = ?, lecturer_email = ?, lecturer_phone = ?,
                lecturer_office_phone = ?, lecturer_department = ?
            WHERE lecturer_id = ?
        ");
        $stmt->execute([
            trim($_POST['staff_id']),
            $_POST['programme'],
            trim($_POST['name']),
            $_POST['gender'],
            trim($_POST['email']),
            trim($_POST['phone']),
            trim($_POST['office_phone']),
            $_POST['department'],
            $lecturer_id,
        ]);
        $pdo->prepare("UPDATE user SET user_name = ?, user_email = ? WHERE user_id = ?")
            ->execute([trim($_POST['name']), trim($_POST['email']), $_SESSION['user_id']]);
        $_SESSION['user_name'] = trim($_POST['name']);
        $_SESSION['user_email'] = trim($_POST['email']);
        $message = 'Profile updated successfully.';
    } catch (Exception $e) {
        $error = 'Update failed: ' . $e->getMessage();
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['change_password'])) {
    $currentPassword = $_POST['current_password'] ?? '';
    $newPassword = $_POST['new_password'] ?? '';
    $confirmPassword = $_POST['confirm_password'] ?? '';

    try {
        $stmt = $pdo->prepare('SELECT user_password FROM user WHERE user_id = ?');
        $stmt->execute([$_SESSION['user_id']]);
        $user = $stmt->fetch();

        if (!$user || !password_verify($currentPassword, $user['user_password'])) {
            $error = 'Current password is incorrect.';
        } elseif (strlen($newPassword) < 8) {
            $error = 'New password must be at least 8 characters.';
        } elseif (!preg_match('/[A-Z]/', $newPassword) || !preg_match('/[a-z]/', $newPassword) || !preg_match('/[0-9]/', $newPassword)) {
            $error = 'New password must include uppercase, lowercase, and a number.';
        } elseif ($newPassword !== $confirmPassword) {
            $error = 'New passwords do not match.';
        } elseif (password_verify($newPassword, $user['user_password'])) {
            $error = 'New password must be different from the current password.';
        } else {
            $stmt = $pdo->prepare('UPDATE user SET user_password = ?, user_must_change_password = 0 WHERE user_id = ?');
            $stmt->execute([password_hash($newPassword, PASSWORD_DEFAULT), $_SESSION['user_id']]);
            $_SESSION['must_change_password'] = false;
            $message = 'Password changed successfully.';
        }
    } catch (Exception $e) {
        $error = 'Unable to change password.';
    }
}

$stmt = $pdo->prepare("SELECT * FROM lecturer WHERE lecturer_id = ?");
$stmt->execute([$lecturer_id]);
$lecturer = $stmt->fetch();
$programmes = ['Bachelor of Accounting (Hons)', 'Bachelor of Accounting (Information Systems) (Hons)'];
$departments = lecturer_departments();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lecturer Profile - InternHub</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .sidebar { min-height: 100vh; background: #2c3e50; }
        .sidebar a { color: white; text-decoration: none; padding: 12px 20px; display: block; transition: 0.3s; }
        .sidebar a:hover, .sidebar a.active { background: #3498db; }
        .content { padding: 20px; }
    </style>
    <link rel="stylesheet" href="">
    <link rel="stylesheet" href="../assets/css/theme.css">
</head>
<body>
<div class="container-fluid">
    <div class="row">
        <div class="col-md-2 p-0 sidebar">
            <div class="sb-brand">
                <img class="sb-logo" src="../assets/img/logo-light.png" alt="TISSA &middot; Universiti Utara Malaysia">
                <span class="sb-wordmark">Intern<span>Hub</span></span>
            </div>
            <hr class="bg-white">
            <a href="lecturer_dashboard.php"><i class="fas fa-tachometer-alt me-2"></i> Dashboard</a>
            <a href="profile.php" class="active"><i class="fas fa-user me-2"></i> Profile</a>
            <a href="interns.php"><i class="fas fa-user-graduate me-2"></i> My Interns</a>
            <a href="logbooks.php"><i class="fas fa-book me-2"></i> Logbooks</a>
            <a href="report.php"><i class="fas fa-table me-2"></i> Reports</a>
            <a href="../logout.php" class="text-danger"><i class="fas fa-sign-out-alt me-2"></i> Logout</a>
        </div>
        <div class="col-md-10 content">
            <div class="text-end text-muted small mb-2">Logged in as <?php echo htmlspecialchars($_SESSION['user_name'] ?? 'Lecturer'); ?></div>
            <h2>Lecturer Profile</h2>
            <?php if ($message): ?><div class="alert alert-success"><?php echo htmlspecialchars($message); ?></div><?php endif; ?>
            <?php if ($error): ?><div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div><?php endif; ?>

            <div class="card">
                <div class="card-body">
                    <form method="POST" class="row g-3">
                        <div class="col-md-4">
                            <label class="form-label">Lecturer ID</label>
                            <input type="text" name="staff_id" class="form-control" value="<?php echo htmlspecialchars($lecturer['lecturer_staff_id'] ?? ''); ?>" required>
                        </div>
                        <div class="col-md-8">
                            <label class="form-label">Programme</label>
                            <select name="programme" class="form-control" required>
                                <?php foreach ($programmes as $programme): ?>
                                    <option value="<?php echo htmlspecialchars($programme); ?>" <?php echo $lecturer['lecturer_programme'] === $programme ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars(programme_short_label($programme)); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Name</label>
                            <input type="text" name="name" class="form-control" value="<?php echo htmlspecialchars($lecturer['lecturer_name']); ?>" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Gender</label>
                            <select name="gender" class="form-control">
                                <?php foreach (['Male', 'Female', 'Other'] as $gender): ?>
                                    <option value="<?php echo $gender; ?>" <?php echo $lecturer['lecturer_gender'] === $gender ? 'selected' : ''; ?>><?php echo $gender; ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">IC Number</label>
                            <input type="text" class="form-control" value="<?php echo htmlspecialchars($lecturer['lecturer_ic'] ?? ''); ?>" readonly>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Email</label>
                            <input type="email" name="email" class="form-control" value="<?php echo htmlspecialchars($lecturer['lecturer_email']); ?>" required>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Phone</label>
                            <input type="text" name="phone" class="form-control" value="<?php echo htmlspecialchars($lecturer['lecturer_phone'] ?? ''); ?>">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Office Phone Number</label>
                            <input type="text" name="office_phone" class="form-control" value="<?php echo htmlspecialchars($lecturer['lecturer_office_phone'] ?? ''); ?>">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Department</label>
                            <select name="department" class="form-control" required>
                                <?php foreach ($departments as $department): ?>
                                    <option value="<?php echo htmlspecialchars($department); ?>" <?php echo ($lecturer['lecturer_department'] ?? '') === $department ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($department); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-12">
                            <button class="btn btn-primary" type="submit" name="update_profile">Save Profile</button>
                        </div>
                    </form>
                </div>
            </div>

            <div class="card mt-4">
                <div class="card-header"><h5 class="mb-0">Change Password</h5></div>
                <div class="card-body">
                    <form method="POST" class="row g-3">
                        <div class="col-md-4">
                            <label class="form-label">Current Password</label>
                            <input type="password" name="current_password" class="form-control" required autocomplete="current-password">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">New Password</label>
                            <input type="password" name="new_password" class="form-control" required minlength="8" autocomplete="new-password">
                            <small class="text-muted">At least 8 characters with uppercase, lowercase, and a number.</small>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Confirm New Password</label>
                            <input type="password" name="confirm_password" class="form-control" required minlength="8" autocomplete="new-password">
                        </div>
                        <div class="col-12">
                            <button class="btn btn-warning" type="submit" name="change_password">Change Password</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>
