<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/evaluation_helpers.php';
require_once __DIR__ . '/../includes/management_helpers.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'lecturer') {
    header('Location: ../login.php');
    exit();
}

$lecturer_id = $_SESSION['lecturer_id'];
ensure_company_evaluation_round_schema($pdo);
$companySummary = company_evaluation_summary_sql('ce');
$stmt = $pdo->prepare("
    SELECT i.*, s.student_name, s.student_email, s.student_course,
           c.company_name, ce.ce_count, ce.ce_total_score, le.le_id, le.le_total_score
    FROM internship i
    JOIN student s ON s.student_id = i.student_id
    JOIN company c ON c.company_id = i.company_id
    LEFT JOIN {$companySummary} ON ce.internship_id = i.internship_id
    LEFT JOIN lecturerevaluation le ON le.internship_id = i.internship_id
    WHERE i.lecturer_id = ?
    ORDER BY CASE WHEN le.le_id IS NULL THEN 0 ELSE 1 END ASC,
             UPPER(s.student_name) ASC
");
$stmt->execute([$lecturer_id]);

$programmeInterns = ['ais' => [], 'accounting' => []];
foreach ($stmt->fetchAll() as $intern) {
    $programme = stripos($intern['student_course'], 'Information Systems') !== false ? 'ais' : 'accounting';
    $programmeInterns[$programme][] = $intern;
}

function render_intern_table(array $interns)
{
    if (!$interns) {
        echo '<div class="alert alert-info mb-0">No assigned interns found in this programme.</div>';
        return;
    }
    ?>
    <div class="table-responsive">
        <table class="table table-hover align-middle">
            <thead><tr><th>Student</th><th>Course</th><th>Company</th><th>Status</th><th>Company Eval</th><th>Lecturer Eval</th><th>Action</th></tr></thead>
            <tbody>
            <?php foreach ($interns as $intern): ?>
                <tr>
                    <td><strong><?php echo htmlspecialchars($intern['student_name']); ?></strong><br><small><?php echo htmlspecialchars($intern['student_email']); ?></small></td>
                    <td><?php echo htmlspecialchars(programme_short_label($intern['student_course'])); ?></td>
                    <td><?php echo htmlspecialchars($intern['company_name']); ?></td>
                    <td><span class="badge bg-secondary"><?php echo htmlspecialchars($intern['internship_status']); ?></span></td>
                    <td><?php echo (int) $intern['ce_count'] === 2 ? '<span class="badge bg-success">' . htmlspecialchars(weighted_company_score($intern['ce_total_score'], 2)) . '/40</span>' : '<span class="badge bg-warning text-dark">' . (int) $intern['ce_count'] . '/2 submitted</span>'; ?></td>
                    <td><?php echo $intern['le_id'] ? '<span class="badge bg-success">' . htmlspecialchars($intern['le_total_score']) . '%</span>' : '<span class="badge bg-warning text-dark">Pending</span>'; ?></td>
                    <td>
                        <?php if ($intern['le_id']): ?>
                            <a href="evaluate.php?internship_id=<?php echo (int) $intern['internship_id']; ?>" class="btn btn-sm btn-primary">View</a>
                        <?php else: ?>
                            <a href="evaluate.php?internship_id=<?php echo (int) $intern['internship_id']; ?>" class="btn btn-sm btn-primary">Evaluate</a>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Interns - InternHub</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .sidebar { min-height: 100vh; background: #2c3e50; }
        .sidebar a { color: white; text-decoration: none; padding: 12px 20px; display: block; transition: .3s; }
        .sidebar a:hover, .sidebar a.active { background: #3498db; }
        .content { padding: 20px; }
        .programme-tabs .nav-link { color: #611525; font-weight: 700; padding: .9rem 1.25rem; }
        .programme-tabs .nav-link.active { color: #fff; background: #611525; border-color: #611525; }
        .programme-count { background: rgba(255,255,255,.2); border-radius: 999px; margin-left: .35rem; padding: .1rem .5rem; }
        .nav-link:not(.active) .programme-count { background: #f0dfe4; }
    </style>
    <link rel="stylesheet" href="../assets/css/theme.css">
</head>
<body>
<div class="container-fluid">
    <div class="row">
        <div class="col-md-2 p-0 sidebar">
            <div class="sb-brand">
                <img class="sb-logo" src="../assets/img/logo-light.png" alt="TISSA &middot; Universiti Utara Malaysia">
                <span class="sb-wordmark">Intern<span>Hub</span></span>
            </div><hr class="bg-white">
            <a href="lecturer_dashboard.php"><i class="fas fa-tachometer-alt me-2"></i> Dashboard</a>
            <a href="profile.php"><i class="fas fa-user me-2"></i> Profile</a>
            <a href="interns.php" class="active"><i class="fas fa-user-graduate me-2"></i> My Interns</a>
            <a href="logbooks.php"><i class="fas fa-book me-2"></i> Logbooks</a>
            <a href="report.php"><i class="fas fa-table me-2"></i> Reports</a>
            <a href="../logout.php" class="text-danger"><i class="fas fa-sign-out-alt me-2"></i> Logout</a>
        </div>
        <div class="col-md-10 content">
            <div class="text-end text-muted small mb-2">Logged in as <?php echo htmlspecialchars($_SESSION['user_name'] ?? 'Lecturer'); ?></div>
            <h2>Assigned Interns</h2>
            <p class="text-muted">Pending evaluations are shown first. Completed evaluations move to the bottom, with each group arranged alphabetically.</p>
            <div class="card">
                <div class="card-body">
                    <ul class="nav nav-tabs programme-tabs mb-3" role="tablist">
                        <li class="nav-item" role="presentation"><button class="nav-link active" data-bs-toggle="tab" data-bs-target="#ais-interns" type="button" role="tab">B.Acct (IS) Students <span class="programme-count"><?php echo count($programmeInterns['ais']); ?></span></button></li>
                        <li class="nav-item" role="presentation"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#accounting-interns" type="button" role="tab">B.Acct Students <span class="programme-count"><?php echo count($programmeInterns['accounting']); ?></span></button></li>
                    </ul>
                    <div class="tab-content">
                        <div class="tab-pane fade show active" id="ais-interns" role="tabpanel"><?php render_intern_table($programmeInterns['ais']); ?></div>
                        <div class="tab-pane fade" id="accounting-interns" role="tabpanel"><?php render_intern_table($programmeInterns['accounting']); ?></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
