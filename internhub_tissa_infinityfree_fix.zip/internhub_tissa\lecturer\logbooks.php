<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/management_helpers.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'lecturer') {
    header('Location: ../login.php');
    exit();
}

$lecturer_id = $_SESSION['lecturer_id'];
$message = '';
$search = trim($_GET['search'] ?? '');

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['mark_review'])) {
    $logbook_id = (int) $_POST['logbook_id'];
    $stmt = $pdo->prepare("
        UPDATE logbook lb
        JOIN internship i ON i.internship_id = lb.internship_id
        SET lb.logbook_status = 'Review'
        WHERE lb.logbook_id = ? AND i.lecturer_id = ?
    ");
    $stmt->execute([$logbook_id, $lecturer_id]);
    $message = 'Logbook marked as reviewed.';
}

$sql = "
    SELECT lb.*, s.student_id, s.student_name, s.student_matric_no, s.student_course,
           c.company_name
    FROM logbook lb
    JOIN internship i ON i.internship_id = lb.internship_id
    JOIN student s ON s.student_id = i.student_id
    JOIN company c ON c.company_id = i.company_id
    WHERE i.lecturer_id = ?
";
$params = [$lecturer_id];
if ($search !== '') {
    $sql .= ' AND s.student_name LIKE ?';
    $params[] = '%' . $search . '%';
}
$sql .= ' ORDER BY UPPER(s.student_name) ASC, lb.logbook_week_no DESC, lb.logbook_submitted_date DESC';
$stmt = $pdo->prepare($sql);
$stmt->execute($params);

$programmeStudents = ['ais' => [], 'accounting' => []];
foreach ($stmt->fetchAll() as $logbook) {
    $programme = stripos($logbook['student_course'], 'Information Systems') !== false ? 'ais' : 'accounting';
    $studentId = (int) $logbook['student_id'];
    if (!isset($programmeStudents[$programme][$studentId])) {
        $programmeStudents[$programme][$studentId] = [
            'name' => $logbook['student_name'],
            'matric_no' => $logbook['student_matric_no'],
            'course' => $logbook['student_course'],
            'logbooks' => [],
        ];
    }
    $programmeStudents[$programme][$studentId]['logbooks'][] = $logbook;
}

function render_student_logbooks(array $students, string $programme)
{
    if (!$students) {
        echo '<div class="alert alert-info mb-0">No submitted logbooks found for this programme.</div>';
        return;
    }
    ?>
    <div class="accordion student-accordion" id="<?php echo $programme; ?>StudentAccordion">
        <?php $studentIndex = 0; ?>
        <?php foreach ($students as $studentId => $student): ?>
            <?php
            $studentCollapse = $programme . 'Student' . $studentId;
            $reviewed = count(array_filter($student['logbooks'], fn($entry) => $entry['logbook_status'] === 'Review'));
            ?>
            <div class="accordion-item mb-3">
                <h2 class="accordion-header">
                    <button class="accordion-button <?php echo $studentIndex ? 'collapsed' : ''; ?>" type="button" data-bs-toggle="collapse" data-bs-target="#<?php echo $studentCollapse; ?>">
                        <span>
                            <strong><?php echo htmlspecialchars($student['name']); ?></strong>
                            <span class="d-block small text-muted"><?php echo htmlspecialchars($student['matric_no']); ?> | <?php echo htmlspecialchars(programme_short_label($student['course'])); ?></span>
                        </span>
                        <span class="student-summary ms-auto me-3"><?php echo count($student['logbooks']); ?> week(s) | <?php echo $reviewed; ?> reviewed</span>
                    </button>
                </h2>
                <div id="<?php echo $studentCollapse; ?>" class="accordion-collapse collapse <?php echo $studentIndex ? '' : 'show'; ?>" data-bs-parent="#<?php echo $programme; ?>StudentAccordion">
                    <div class="accordion-body">
                        <?php foreach ($student['logbooks'] as $logbook): ?>
                            <div class="logbook-entry">
                                <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3">
                                    <h5 class="mb-0">Week <?php echo (int) $logbook['logbook_week_no']; ?></h5>
                                    <span class="badge bg-<?php echo $logbook['logbook_status'] === 'Review' ? 'success' : 'warning text-dark'; ?>"><?php echo htmlspecialchars($logbook['logbook_status']); ?></span>
                                </div>
                                <div class="row small text-muted mb-3">
                                    <div class="col-md-6"><strong>Company:</strong> <?php echo htmlspecialchars($logbook['company_name']); ?></div>
                                    <div class="col-md-6"><strong>Submitted:</strong> <?php echo htmlspecialchars($logbook['logbook_submitted_date']); ?></div>
                                </div>
                                <h6>Tasks</h6>
                                <p><?php echo nl2br(htmlspecialchars($logbook['logbook_task'])); ?></p>
                                <h6>Problems</h6>
                                <p><?php echo nl2br(htmlspecialchars($logbook['logbook_problem'] ?: '-')); ?></p>
                                <h6>Solutions / Learning Outcomes</h6>
                                <p><?php echo nl2br(htmlspecialchars($logbook['logbook_solutions'] ?: '-')); ?></p>
                                <?php if ($logbook['logbook_status'] !== 'Review'): ?>
                                    <form method="POST">
                                        <input type="hidden" name="logbook_id" value="<?php echo (int) $logbook['logbook_id']; ?>">
                                        <button class="btn btn-sm btn-success" name="mark_review" type="submit">Mark Reviewed</button>
                                    </form>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
            <?php $studentIndex++; ?>
        <?php endforeach; ?>
    </div>
    <?php
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Logbooks - InternHub</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .sidebar { min-height: 100vh; background: #2c3e50; }
        .sidebar a { color: white; text-decoration: none; padding: 12px 20px; display: block; transition: .3s; }
        .sidebar a:hover, .sidebar a.active { background: #3498db; }
        .content { padding: 20px; }
        .programme-tabs .nav-link { color: #611525; font-weight: 700; padding: .9rem 1.25rem; }
        .programme-tabs .nav-link.active { color: #fff; background: #611525; border-color: #611525; }
        .programme-count { background: rgba(255,255,255,.2); border-radius: 999px; margin-left: .35rem; padding: .1rem .5rem; }
        .nav-link:not(.active) .programme-count { background: #f0dfe4; }
        .student-accordion .accordion-item { border: 1px solid #ead8dd; border-radius: .5rem; overflow: hidden; }
        .student-accordion .accordion-button:not(.collapsed) { color: #611525; background: #f8eef1; }
        .student-summary { color: #6c757d; font-size: .85rem; font-weight: 600; }
        .logbook-entry { border: 1px solid #ead8dd; border-radius: .5rem; padding: 1rem; margin-bottom: 1rem; }
        .logbook-entry:last-child { margin-bottom: 0; }
    </style>
    <link rel="stylesheet" href="../assets/css/theme.css">
</head>
<body>
<div class="container-fluid">
    <div class="row">
        <div class="col-md-2 p-0 sidebar">
            <div class="sb-brand">
                <img class="sb-logo" src="../assets/img/logo-light.png" alt="TISSA &middot; Universiti Utara Malaysia">
                <span class="sb-wordmark">Intern<span>Hub</span></span>
            </div><hr class="bg-white">
            <a href="lecturer_dashboard.php"><i class="fas fa-tachometer-alt me-2"></i> Dashboard</a>
            <a href="profile.php"><i class="fas fa-user me-2"></i> Profile</a>
            <a href="interns.php"><i class="fas fa-user-graduate me-2"></i> My Interns</a>
            <a href="logbooks.php" class="active"><i class="fas fa-book me-2"></i> Logbooks</a>
            <a href="report.php"><i class="fas fa-table me-2"></i> Reports</a>
            <a href="../logout.php" class="text-danger"><i class="fas fa-sign-out-alt me-2"></i> Logout</a>
        </div>
        <div class="col-md-10 content">
            <div class="text-end text-muted small mb-2">Logged in as <?php echo htmlspecialchars($_SESSION['user_name'] ?? 'Lecturer'); ?></div>
            <h2>Student Logbooks for Evaluation</h2>
            <p class="text-muted">Students are grouped by programme and arranged alphabetically.</p>
            <?php if ($message): ?><div class="alert alert-success"><?php echo htmlspecialchars($message); ?></div><?php endif; ?>

            <div class="card mb-3"><div class="card-body">
                <form method="GET" class="row g-2">
                    <div class="col-md-9"><input type="text" name="search" class="form-control" placeholder="Search by student name" value="<?php echo htmlspecialchars($search); ?>"></div>
                    <div class="col-md-3"><button class="btn btn-primary w-100" type="submit">Search</button></div>
                </form>
            </div></div>

            <div class="card"><div class="card-body">
                <ul class="nav nav-tabs programme-tabs mb-3" role="tablist">
                    <li class="nav-item"><button class="nav-link active" data-bs-toggle="tab" data-bs-target="#ais-logbooks" type="button">B.Acct (IS) Students <span class="programme-count"><?php echo count($programmeStudents['ais']); ?></span></button></li>
                    <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#accounting-logbooks" type="button">B.Acct Students <span class="programme-count"><?php echo count($programmeStudents['accounting']); ?></span></button></li>
                </ul>
                <div class="tab-content">
                    <div class="tab-pane fade show active" id="ais-logbooks"><?php render_student_logbooks($programmeStudents['ais'], 'ais'); ?></div>
                    <div class="tab-pane fade" id="accounting-logbooks"><?php render_student_logbooks($programmeStudents['accounting'], 'accounting'); ?></div>
                </div>
            </div></div>
        </div>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
