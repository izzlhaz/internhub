<?php
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/student_upload_helpers.php';

if (!isset($_SESSION['user_id'], $_SESSION['user_role'])) {
    http_response_code(403);
    exit;
}

ensure_student_upload_schema($pdo);
$studentId = (int) ($_GET['id'] ?? ($_SESSION['student_id'] ?? 0));
if ($_SESSION['user_role'] === 'student' && $studentId !== (int) ($_SESSION['student_id'] ?? 0)) {
    http_response_code(403);
    exit;
}

$stmt = $pdo->prepare('SELECT student_photo_type, student_photo_data FROM student WHERE student_id = ? AND student_photo_data IS NOT NULL');
$stmt->execute([$studentId]);
$photo = $stmt->fetch();
if (!$photo) {
    http_response_code(404);
    exit;
}

header('Content-Type: ' . $photo['student_photo_type']);
header('Content-Length: ' . strlen($photo['student_photo_data']));
header('Cache-Control: private, max-age=300');
header('X-Content-Type-Options: nosniff');
echo $photo['student_photo_data'];
